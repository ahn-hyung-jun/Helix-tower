#include <GL/freeglut.h>
#include <cmath>
#include <stdlib.h>
#include <time.h>
#include "main.h"
#include "tower.h"

#define DISTANCE_OF_FLOOR 2

int level = 1;
int Game_state = 1;	//0 = Ÿ��Ʋ 1 = ������ 2 = ���� 3 = ����


Tower tower;
mouse_ first_click;
mouse_ moved_mouse;
bool drag = false;
double zoom = 0;


GLubyte *pBytes;
BITMAPINFO *info;
GLuint textures[1];





void main(int argc, char *argv[])
{
	//�ʱ�ȭ �Լ���
	tower.Initialize(1);
	srand(time(NULL));
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH); // ���÷��� ��� ����	// �������۸� && 3�������� �׸���.
	glutInitWindowPosition(100, 100); // �������� ��ġ����
	glutInitWindowSize(800, 800); // �������� ũ�� ����
	glutCreateWindow("Example"); // ������ ���� (������ �̸�)
	glutDisplayFunc(drawScene); // ��� �Լ��� ����
	glutReshapeFunc(Reshape); // �ٽ� �׸��� �Լ��� ����
	glutMouseFunc(Mouse);	// ���콺 �Է�
	glutMotionFunc(Motion);
	glutKeyboardFunc(Keyboard);		// Ű���� �Է�
	glutTimerFunc(100/3, Timerfunction, 1);
	glutMainLoop();
}
// ������ ��� �Լ�
GLvoid drawScene(GLvoid)
{
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // ������ �����! �����!
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // ������ ������ ��ü�� ĥ�ϱ�, ���̹��� Ŭ����

	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	GLfloat specref[] = { 1.0f,1.0f,1.0f,1.0f };

	glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
	glMateriali(GL_FRONT, GL_SHININESS, 64);

	glEnable(GL_AUTO_NORMAL);
	Draw_Background();
	glPushMatrix();
	{
		glTranslated(0, 0.5, -1);
		glRotated(30, 1, 0, 0);
		if (tower.Get_ball_camera_follow() == true)
		{
			glTranslated(0, -tower.Get_ball_y(), 0);
		}
		else
		{
			glTranslated(0, -tower.Get_ball_floor()*-DISTANCE_OF_FLOOR, 0);
		}
		Control_light();
		if (Game_state == 1 || Game_state == 2)
		{
			glTranslated(0, 1.5 - zoom*0.075, 0);
			glScaled(0.2 + zoom*0.04, 0.05+zoom*0.0475, 0.2+zoom*0.04);
		}
		tower.Draw_Tower();
	}
	glPopMatrix();

	glutSwapBuffers();
}
GLvoid Reshape(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(60.0, w / h, 1, 200.0);
	glTranslated(0.0, -1.0, -3);

	glEnable(GL_TEXTURE_2D);
	glMatrixMode(GL_MODELVIEW);
	glEnable(GL_DEPTH_TEST);	// ��������!
	glLoadIdentity();
}
void Timerfunction(int value)
{
	if (Game_state == 2)
	{
		zoom += 1;
		if (zoom > 19)
		{
			Game_state = 3;
			zoom = 0;
		}
	}


	if (Game_state == 3)
	{
		tower.Update();
	}
	glutPostRedisplay();	// ȭ�� �����
	glutTimerFunc(100/3, Timerfunction, 1);
}
void Keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'Y':
		//glRotated(5, 1, 0, 0);
		tower.Rotate_plus();
		break;
	case'y':
		//glRotated(5, 0, 1, 0);
		tower.Rotate_minus();
		break;
	case'x':
		glRotated(5, 1, 0, 0);
		break;
	case '1':	
		if (Game_state == 1)
		{
			level = 1;
			tower.Initialize(1);
		}
		break;
	case'2':
		if (Game_state == 1)
		{
			level = 2;
			tower.Initialize(2);
		}
		break;
	case'3':
		if (Game_state == 1)
		{
			level = 3;
			tower.Initialize(3);
		}
		break;
	case'4':
		if (Game_state == 1)
		{
			level = 4;
			tower.Initialize(4);
		}
		break;
	case'5':
		if (Game_state == 1)
		{
			level = 5;
			tower.Initialize(5);
		}
		break;
	case'6':
		if (Game_state == 1)
		{
			level = 6;
			tower.Initialize(6);
		}
		break;
	case's':
		if (Game_state == 1)
		{
			Game_state = 2;
		}
		break;
	}
	glutPostRedisplay();	// ȭ�� �����!
}


void Mouse(int button, int state, int x, int y)
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		drag = true;
		first_click.x = x;
	}

	if (button == GLUT_LEFT_BUTTON && state == GLUT_UP)
	{
		drag = false;
		tower.Fix_degree();
	}
}

void Motion(int xp, int yp)
{
	moved_mouse.x = xp;

	if (drag == true)
	{
		int moving = moved_mouse.x - first_click.x;
		tower.Rotate_by_mouse(-moving);
	}

}

void Control_light()
{
	GLfloat AmbientLight[] = { 0.2f,  0.2f,  0.2f,  1.0f };
	GLfloat DiffuseLight[] = { 1.0, 1 , 1, 1.0 };
	GLfloat SpecularLight[] = { 0.5,0.5,0.5,1.0 };
	GLfloat lightPos_1[] = { 1, 1, 1, 1.0 };

	GLfloat AmbientLight2[] = { 0.2f,  0.2f ,  0.2f,  1.0f };
	GLfloat DiffuseLight2[] = { 1 , 1 , 1.0 , 1.0 };
	GLfloat SpecularLight2[] = { 0.5 ,0.5 ,0.5 ,1.0 };
	GLfloat lightPos_2[] = { -1, 1, 1, 1.0 };

	

	GLfloat gray[] = { 0.2f,0.2f,0.2f,1.0f };


	glEnable(GL_LIGHTING);

	glLightfv(GL_LIGHT0, GL_AMBIENT, AmbientLight);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, DiffuseLight);
	glLightfv(GL_LIGHT0, GL_SPECULAR, SpecularLight);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos_1);
	glEnable(GL_LIGHT0);

	glLightfv(GL_LIGHT1, GL_AMBIENT, AmbientLight2);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, DiffuseLight2);
	glLightfv(GL_LIGHT1, GL_SPECULAR, SpecularLight2);
	glLightfv(GL_LIGHT1, GL_POSITION, lightPos_2);
	glEnable(GL_LIGHT1);

	
	
}
void Draw_Background()
{
	Init_Texture(pBytes, info, textures);
	glBindTexture(GL_TEXTURE_2D, textures[0]);

	glPushMatrix();
	glTranslated(0, 0, -10);

	glBegin(GL_POLYGON);
		glColor3f(1, 1, 1);
		glTexCoord2i(0, 1);
		glVertex3f(-10, 10, 0);

		glTexCoord2i(1, 1);
		glVertex3f(10, 10, 0);

		glTexCoord2i(1, 0);
		glVertex3f(10, -10, 0);

		glTexCoord2i(0, 0);
		glVertex3f(-10, -10, 0);
	glEnd();

	glPopMatrix();
}